package com.santa.overlay;

import android.app.*;import android.content.*;import android.graphics.PixelFormat;import android.os.*;import android.provider.Settings;import android.view.*;

public class OverlayService extends Service {
    private WindowManager wm; private OverlayCanvasView view; private OverlaySettings settings;
    @Override public void onCreate(){super.onCreate();settings=new OverlaySettings(this);startForeground(7,notification());}
    private Notification notification(){String ch="santa_overlay"; if(Build.VERSION.SDK_INT>=26)((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(new NotificationChannel(ch,"Santa Overlay",NotificationManager.IMPORTANCE_LOW)); return new Notification.Builder(this,ch).setContentTitle("Santa").setContentText("Overlay is running").setSmallIcon(android.R.drawable.ic_menu_view).build();}
    @Override public int onStartCommand(Intent i,int f,int id){ if(!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY;} if(view==null){wm=(WindowManager)getSystemService(WINDOW_SERVICE);view=new OverlayCanvasView(this,settings);int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;WindowManager.LayoutParams lp=new WindowManager.LayoutParams(-1,-1,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);wm.addView(view,lp);}return START_STICKY;}
    @Override public void onDestroy(){if(view!=null){wm.removeView(view);view=null;}super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
