package com.santa.overlay;

import android.app.*;import android.content.*;import android.graphics.Color;import android.net.Uri;import android.os.*;import android.provider.Settings;import android.view.*;import android.widget.*;

public class MainActivity extends Activity {
    OverlaySettings s; LinearLayout root;
    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);} TextView tv(String x){TextView t=new TextView(this);t.setText(x);t.setTextSize(16);t.setTextColor(Color.WHITE);t.setPadding(dp(16),dp(12),dp(16),dp(12));return t;}
    @Override public void onCreate(Bundle b){super.onCreate(b);s=new OverlaySettings(this);build();}
    void build(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(28),dp(18),dp(18));root.setBackgroundColor(Color.rgb(18,18,22)); TextView title=tv("Santa");title.setTextSize(28);root.addView(title);root.addView(tv("SharpShot-style overlay • improved M / N / Q alignment"));
        Button access=new Button(this);access.setText(Settings.canDrawOverlays(this)?"Overlay permission: OK":"Grant overlay permission");access.setOnClickListener(v->{if(!Settings.canDrawOverlays(this))startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));});root.addView(access);
        addSeek("Scale",.5f,2f,s.scale,v->{s.scale=v;s.save();}); addSeek("Opacity",.2f,1f,s.opacity,v->{s.opacity=v;s.save();});
        TextView calib=tv("Letter calibration\nM: 0, 0     N: 0, 0     Q: 0, 0\nDrag the overlay to position it. The three letters use independent offsets.");root.addView(calib);
        Button start=new Button(this);start.setText("START SANTA OVERLAY");start.setOnClickListener(v->{if(Settings.canDrawOverlays(this)){Intent i=new Intent(this,OverlayService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);Toast.makeText(this,"Santa overlay started",Toast.LENGTH_SHORT).show();}else Toast.makeText(this,"Grant overlay permission first",Toast.LENGTH_SHORT).show();});root.addView(start);setContentView(root);}
    interface F{void set(float v);} void addSeek(String name,float min,float max,float val,F f){TextView label=tv(name);root.addView(label);SeekBar sb=new SeekBar(this);sb.setMax(1000);sb.setProgress((int)((val-min)/(max-min)*1000));sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean u){f.set(min+(max-min)*p/1000f);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});root.addView(sb);}
    @Override protected void onResume(){super.onResume();if(root!=null)build();}
}
