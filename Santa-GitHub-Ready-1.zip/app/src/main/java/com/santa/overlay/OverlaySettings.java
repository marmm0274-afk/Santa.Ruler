package com.santa.overlay;

import android.content.Context;
import android.content.SharedPreferences;

public final class OverlaySettings {
    private final SharedPreferences p;
    public float scale, opacity, x, y;
    public float mX, mY, nX, nY, qX, qY;
    public OverlaySettings(Context c) {
        p=c.getSharedPreferences("santa", Context.MODE_PRIVATE);
        scale=p.getFloat("scale",1f); opacity=p.getFloat("opacity",0.92f);
        x=p.getFloat("x",0f); y=p.getFloat("y",0f);
        mX=p.getFloat("mX",0f); mY=p.getFloat("mY",0f);
        nX=p.getFloat("nX",0f); nY=p.getFloat("nY",0f);
        qX=p.getFloat("qX",0f); qY=p.getFloat("qY",0f);
    }
    public void save(){ p.edit().putFloat("scale",scale).putFloat("opacity",opacity).putFloat("x",x).putFloat("y",y)
        .putFloat("mX",mX).putFloat("mY",mY).putFloat("nX",nX).putFloat("nY",nY).putFloat("qX",qX).putFloat("qY",qY).apply(); }
}
