package com.santa.overlay;

import android.graphics.*;
import android.view.*;
import android.content.Context;

public class OverlayCanvasView extends View {
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); private final OverlaySettings s;
    private float downX,downY,baseX,baseY;
    public OverlayCanvasView(Context c, OverlaySettings settings){super(c);s=settings;setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    private void text(Canvas c,String t,float cx,float cy,float size){
        p.setStyle(Paint.Style.FILL); p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD)); p.setTextSize(size*s.scale); p.setColor(Color.WHITE); p.setAlpha((int)(255*s.opacity)); p.setTextAlign(Paint.Align.CENTER);
        c.drawText(t,cx,cy-(p.ascent()+p.descent())/2,p);
    }
    @Override protected void onDraw(Canvas c){ super.onDraw(c); float w=getWidth(),h=getHeight(); float cx=w/2+s.x, cy=h/2+s.y;
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2*s.scale);p.setColor(Color.WHITE);p.setAlpha((int)(180*s.opacity));
        c.drawCircle(cx,cy,30*s.scale,p); c.drawLine(cx-46*s.scale,cy,cx+46*s.scale,cy,p); c.drawLine(cx,cy-46*s.scale,cx,cy+46*s.scale,p);
        float gap=76*s.scale;
        // Calibrated independently: M, N and Q no longer share a single baseline.
        text(c,"M",cx-gap+s.mX,cy+s.mY,28); text(c,"N",cx+s.nX,cy+s.nY,28); text(c,"Q",cx+gap+s.qX,cy+s.qY,28);
    }
    @Override public boolean onTouchEvent(android.view.MotionEvent e){ if(e.getAction()==MotionEvent.ACTION_DOWN){downX=e.getRawX();downY=e.getRawY();baseX=s.x;baseY=s.y;return true;} if(e.getAction()==MotionEvent.ACTION_MOVE){s.x=baseX+e.getRawX()-downX;s.y=baseY+e.getRawY()-downY;invalidate();return true;} if(e.getAction()==MotionEvent.ACTION_UP){s.save();return true;} return true; }
}
