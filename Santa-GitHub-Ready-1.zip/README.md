# Santa

Android overlay project inspired by the supplied **SharpShot Mob.apk** reference.

## What is included
- App name: **Santa**
- Package: `com.santa.overlay`
- Overlay service with Android 8+ application overlay support
- Draggable overlay canvas
- Independent M / N / Q positions (fixes baseline/spacing issues)
- Scale and opacity controls
- GitHub Actions workflow that builds a debug APK automatically

## Build locally
Requires JDK 17 and Android SDK 35. From the project root:

```bash
gradle --no-daemon clean assembleDebug
```

APK after build: `Santa.apk` (the GitHub Actions workflow renames the generated APK automatically)

## Build on GitHub
Push the repository, then open **Actions → Build Santa APK → Run workflow**. The generated **Santa.apk** is uploaded as a GitHub Actions artifact named **Santa-apk**. Download that artifact and install `Santa.apk` on your Android device.

> The original APK's Firebase/access credentials are intentionally not copied into this project. Any backend/authentication used by the original app must be configured separately with your own project credentials.
